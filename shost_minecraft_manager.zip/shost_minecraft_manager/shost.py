from flask import Flask, render_template, request, jsonify
import os
import zipfile
import subprocess
import socket

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=BASE_DIR)

server_process = None
console_logs = []

def find_free_port(starting_port=5000):
    port = starting_port
    while port < 6000:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(('localhost', port)) != 0:
                return port
            port += 1
    return starting_port

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/command', methods=['POST'])
def send_command():
    global server_process
    data = request.get_json()
    command = data.get('command', '')

    if server_process and server_process.poll() is None:
        server_process.stdin.write(f"{command}\n".encode())
        server_process.stdin.flush()
        return jsonify({"status": "success", "message": f"Befehl '{command}' gesendet."})
    else:
        console_logs.append(f"[DEMO-MODUS] Befehl: {command}")
        return jsonify({"status": "demo", "message": f"Demo-Modus: '{command}' empfangen."})

@app.route('/api/toggle-cracked', methods=['POST'])
def toggle_cracked():
    data = request.get_json()
    cracked = data.get('cracked', True)
    
    prop_file = 'server.properties'
    if os.path.exists(prop_file):
        lines = []
        with open(prop_file, 'r') as f:
            lines = f.readlines()
        
        with open(prop_file, 'w') as f:
            for line in lines:
                if line.startswith('online-mode='):
                    f.write(f"online-mode={'false' if cracked else 'true'}\n")
                else:
                    f.write(line)
        mode_str = "Cracked (Offline-Mode)" if cracked else "Premium (Online-Mode)"
        return jsonify({"status": "success", "message": f"Server-Modus auf {mode_str} gestellt!"})
    
    return jsonify({"status": "warning", "message": "Keine 'server.properties' gefunden."})

@app.route('/api/logs', methods=['GET'])
def get_logs():
    return jsonify({"logs": console_logs[-50:]})

@app.route('/api/stop', methods=['POST'])
def stop_and_backup():
    global server_process
    if server_process and server_process.poll() is None:
        server_process.stdin.write("stop\n".encode())
        server_process.stdin.flush()
        server_process.wait()

    world_folder = 'world'
    backup_zip = 'world_backup.zip'

    if os.path.exists(world_folder):
        with zipfile.ZipFile(backup_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(world_folder):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, world_folder)
                    zipf.write(file_path, arcname)
        return jsonify({"status": "success", "message": "Server gestoppt & Welt als 'world_backup.zip' gesichert!"})
    
    return jsonify({"status": "warning", "message": "Server gestoppt, aber kein 'world'-Ordner zum Sichern gefunden."})

if __name__ == '__main__':
    port = find_free_port(5000)
    print("⚡ S.HOST Manager gestartet!")
    print(f"🌐 Öffne http://localhost:{port} in deinem Browser")
    app.run(host='0.0.0.0', port=port, debug=False)
