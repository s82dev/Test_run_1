S.HOST - Minecraft Test-Server Manager (Updated)
=====================================================

Features:
- Whitelist & Blacklist Steuerung
- Cracked / Online-Mode Umschalter
- Live Console Log Fenster
- Auto-Backup der Welt beim Stoppen (.zip)
- Automatisches Ausweichen auf freie Ports (5000, 5001, etc.)

Starten:
1. 'pip install -r requirements.txt' ausführen.
2. 'python shost.py' ausführen.
3. Den im Terminal angezeigten Link öffnen.
